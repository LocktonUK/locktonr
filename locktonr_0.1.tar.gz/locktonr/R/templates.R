


#' Function to copy Lockton PowerPoint template
#'
#' @param copy_to directory location of where to copy template file to.
#' Default is the current working directory
#' @param new_filename Optional. Filename for copied template (e.g. "NewPresentation")
#'
#' @export
get_lockton_pptx_template <- function(copy_to = getwd(),
                                      new_filename = NULL){

  if(!file.exists(copy_to)){
    stop("Invalid path given in 'copy_to' parameter.")
  }

  file.copy(from = system.file("extdata/Lockton Re - Global Brand - pptx template.pptx", package = "locktonr"),
            to = getwd())

  if(!is.null(new_filename)){
    new_filename_full <- paste0(copy_to, "/", new_filename, ".pptx")
    file.rename(from = paste0(copy_to, "/", "Lockton_template.pptx"),
                to = paste0(copy_to, "/", new_filename, ".pptx"))
  } else {
    new_filename_full <- paste0(copy_to, "/", "Lockton_template", ".pptx")
  }

  new_filename_full
}
