
#' Function to import Lockton fonts
#' @description Only need to run one time to install fonts on your machine
#' @export
import_lockton_fonts <- function(){

  font_table <- extrafont::fonts()

  if(all(c("Sarabun", "EB Garamond") %in% font_table)){
    stop("Fonts already imported. No need to run function again.")
  }

  extrafont::ttf_import(system.file("extdata/fonts", package = "locktonr"))

}
