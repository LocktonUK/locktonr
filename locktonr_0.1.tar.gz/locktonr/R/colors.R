

#' Old Lockton Color Scheme
#'
#' List of old Lockton colors
#'
#' Convenience list of Lockton colors in #hex format.  Just type
#' names(lockton_colors) to see the list of colors included.
#'
#' @examples
#'
#' \dontrun{ggplot() + geom_line(aes(x=-5:5, y=(-5:5)^2), colour=lockton_colors$gold)}
#'
#' @export
lockton_colors <- list(gold = "#FEBE10", blue_gray = "#5B6770", dark_blue = "#002F6C",
                       green = "#23AE49", gray = "#A2AAAD", turquoise = "#0083BE", red = "#CB333B",
                       lighter_gold = "#FEBE103F", lighter_blue_gray = "#5B67703F", lighter_dark_blue = "#002F6C3F",
                       lighter_green = "#23AE493F", lighter_gray = "#A2AAAD3F", lighter_turquoise = "#0083BE3F", lighter_red = "#CB333B3F",
                       light_gold = "#FEBE10A5", light_blue_gray = "#5B6770A5", light_dark_blue = "#002F6CA5",
                       light_green = "#23AE49A5", light_gray = "#A2AAADA5", light_turquoise = "#0083BEA5", light_red = "#CB333BA5")

#' Default Lockton Color Scheme
#'
#' List of default Lockton colors
#'
#' Convenience list of Lockton colors in #hex format.  Just type
#' names(lockton_new_colors) to see the list of colors included.
#'
#' @examples
#'
#' \dontrun{ggplot() + geom_line(aes(x=-5:5, y=(-5:5)^2), colour=lockton_new_colors$blue)}
#'
#' @export
lockton_new_colors <- list(black = "#000000", blue = "#00AEEF",
                           dark_gray = "#5B6770", light_gray = "#A2AAAD",
                           pink = "#EF5399", green = "#00AE5E", yellow = "#FFD534",
                           orange = "#F68A33", red = "#CB333B",
                           light_blue = "#00AEEF66", dark_light_gray = "#5B677066",
                           light_light_gray = "#A2AAAD66", light_pink = "#EF539966",
                           light_green = "#00AE5E66", light_yellow = "#FFD53466",
                           light_orange = "#F68A3366", light_red = "#CB333B66",
                           lighter_blue = "#00AEEF33", dark_lighter_gray = "#5B677033",
                           lighter_light_gray = "#A2AAAD33", lighter_pink = "#EF539933",
                           lighter_green = "#00AE5E33", lighter_yellow = "#FFD53433",
                           lighter_orange = "#F68A3333", lighter_red = "#CB333B33",
                           white = "#FFFFFF")

