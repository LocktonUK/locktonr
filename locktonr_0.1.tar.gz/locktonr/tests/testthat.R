library(testthat)
library(locktonr)

test_check("locktonr")
