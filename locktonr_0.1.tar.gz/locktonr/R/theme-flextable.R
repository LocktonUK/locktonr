
#' @title Apply theme to a flextable
#' @description Apply theme to a flextable
#' @param x a flextable object
#' @param font_size font size to use, part = "all"
#' @param font_family font family
#' @param add_w extra width to add in inches
#' @param add_h extra height to add in inches
#' @param add_h_header extra header height to add in inches
#' @examples
#' ft <- flextable::flextable(iris)
#' ft <- ft_lockton_theme(ft)
#' @export
ft_lockton_theme <- function(x, font_size = 10, font_family = "Sarabun",
                             add_w = 0.1, add_h = 0.05, add_h_header = 0.05){

  if(!(font_family %in% extrafont::fonts())){
    stop(paste0(font_family, " font not found. Run `import_lockton_fonts()` function."))
  }
  if (Sys.info()[["sysname"]]=="Windows"){
    device <- "win"
  } else {
    device <- "pdf"
  }
  extrafont::loadfonts(device, quiet = TRUE)

  num_header_rows <- length(x$header$rowheights)
  header_font_color <- lockton_new_colors$blue
  top_bottom_border_color <- lockton_new_colors$blue
  body_border_color <- lockton_new_colors$light_gray
  x <- x %>% flextable::border_remove()

  x <- x %>% flextable::hline_bottom(border = officer::fp_border(color = top_bottom_border_color, width = 1),
                                     part = "header") %>%
    flextable::color(color = header_font_color, part = "header") %>%
    flextable::hline(border = officer::fp_border(color = body_border_color), part = "body") %>%
    flextable::empty_blanks() %>%
    flextable::hline_bottom(border = officer::fp_border(color = top_bottom_border_color, width = 2), part = "body") %>%
    flextable::hline_top(border = officer::fp_border(color = top_bottom_border_color, width = 2), part = "header") %>%
    flextable::autofit(add_w = add_w, add_h = add_h) %>%
    flextable::padding(padding.right = 4, part = "all") %>%
    flextable::padding(padding.top = 2, padding.bottom = 4, part = "header") %>%
    flextable::vline_left(border = officer::fp_border(color = "white", style = "solid", width = 1)) %>%
    flextable::vline_right(border = officer::fp_border(color = "white", style = "solid", width = 1)) %>%
    flextable::fontsize(size = font_size, part = "all") %>%
    flextable::font(fontname = font_family, part = "all")

  x$header$rowheights <- x$header$rowheights + add_h_header
  if (num_header_rows > 1) {
    x <- x %>% flextable::align(1, align = "center", part = "header")
  }
  x
}


#' @export
#' @title Add a title in headers
#'
#' @description Add a title in the flextable's header part. It can
#' be inserted at the top or the bottom of header part.
#'
#' @details
#' An horizontal and a vertical merge are performed automatically.
#' Use \code{\link{merge_none}} to drop theses merging instructions.
#'
#' @param x a \code{flextable} object
#' @param title a string containing the title of the table
#' @param font_size integer to use for font size of the title
#' @param font_family font family
#' @examples
#' ft <- flextable::flextable( utils::head( iris ),
#'   col_keys = c("Species", "Sepal.Length", "Petal.Length", "Sepal.Width", "Petal.Width") )
#' ft_wtitle <- add_title_header(ft, "Iris data set")
add_title_header <- function(x, title, font_size = 11, font_family = "Sarabun"){

  if(!(font_family %in% extrafont::fonts())){
    stop(paste0(font_family, " font not found. Run `import_lockton_fonts()` function."))
  }

  x_ <- x
  first_row_height <- x$body$rowheights[1]
  save_spans_cols <- x$header$spans$columns
  non_blank_keys <- x$col_keys[!(x$col_keys %in% x$blanks)]

  border_color <- lockton_new_colors$blue
  font_color <- lockton_new_colors$blue

  call_list <- list(x=x, top=TRUE)
  call_list[[colnames(x$body$dataset)[1]]] <- title

  x <- do.call(flextable::add_header, call_list) %>% flextable::merge_h(part = "header")
  x <- x %>% flextable::border(i = 1, border.top = officer::fp_border(color = "transparent"),
                               border.bottom = officer::fp_border(color = border_color, width = 2),
                               part = 'header') %>%
    flextable::fontsize(i = 1, part = 'header', size = font_size) %>%
    flextable::height(i = 1, part = 'header', height = first_row_height) %>%
    flextable::bold(i = 1, bold = TRUE, part = "header") %>%
    flextable::align(i = 1, align = 'left', part = 'header') %>%
    flextable::color(i=1, color = font_color, part = "header") %>%
    flextable::font(fontname = font_family, part = "all")

  x$header$spans$rows[1,] <- c(ncol(x_$body$dataset), rep(0, ncol(x_$body$dataset)-1))
  x$header$spans$columns[2:(nrow(save_spans_cols) + 1),] <- save_spans_cols

  x
}


