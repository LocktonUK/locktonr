
#' Lockton color palette (discrete)
#'
#' Lockton color palette
#'
#' @family colour lockton
#' @export
lockton_pal <- function() {
  values <- unname(lockton_new_colors)
  f <- scales::manual_pal(values)
  attr(f, "max_n") <- length(values)
  f
}

#' Lockton Color Scales
#'
#' Lockton color scales
#'
#' @inheritParams lockton_pal
#' @inheritParams ggplot2::scale_colour_hue
#' @family colour lockton
#' @rdname scale_lockton
#' @export
scale_fill_lockton <- function(...) {
  ggplot2::discrete_scale("fill", "lockton", lockton_pal(), ...)
}

#' @export
#' @rdname scale_lockton
scale_colour_lockton <- function(...) {
  ggplot2::discrete_scale("colour", "lockton", lockton_pal(), ...)
}

#' @export
#' @rdname scale_lockton
scale_color_lockton <- scale_colour_lockton


#' Custom Lockton ggplot2 theme
#'
#' Use ggplot2's theming facility to set defaults
#'
#' This function sets the default look (colors, linetypes, etc.) of ggplot2 to
#' match color scheme. Exhibits not made with ggplot2 will not
#' be affected.
#'
#' @param base_size default font size
#' @param base_family font family to use. Default is "sans".
#'
#' @seealso \code{\link{theme_bw}}, \code{\link{theme_set}}
#' @examples
#'
#' gg_lockton_theme()
#'
#' @export
gg_lockton_theme <- function(base_size=10, base_family="sans") {
  ggplot2::theme_bw(base_size = base_size, base_family = base_family) +
     ggplot2::theme(
        panel.border = ggplot2::element_blank(),
        plot.background = ggplot2::element_blank(),
        panel.background = ggplot2::element_blank(),
        axis.line = ggplot2::element_line(colour = "black"),
        panel.grid.major = ggplot2::element_line(color = "#F2F2F2", linetype = "dashed"),
        panel.grid.major.x = ggplot2::element_blank(),
        panel.grid.minor = ggplot2::element_line(),
        panel.grid.minor.x = ggplot2::element_blank(),
        panel.grid.minor.y = ggplot2::element_blank(),
        strip.background = ggplot2::element_rect(colour = "white", size = 0.5),
        legend.key = ggplot2::element_blank(),
        strip.text = ggplot2::element_text(color = lockton_new_colors$blue, family = base_family),
        axis.line.x = ggplot2::element_line(color = "#F2F2F2", size = 0.5),
        axis.line.y = ggplot2::element_line(color = "#F2F2F2", size = 0.5),
        axis.ticks = ggplot2::element_line(color = "#F2F2F2"),
        plot.title = ggplot2::element_text(hjust = 0, size = 11, color = lockton_new_colors$black, family = base_family),
        plot.subtitle = ggplot2::element_text(hjust = 0, size = 9, color = lockton_new_colors$blue, family = base_family),
        text = ggplot2::element_text(colour = "black", size = base_size, family = base_family),
        axis.text = ggplot2::element_text(colour = "black", size = base_size),
        line = ggplot2::element_line(linetype = "solid", colour = lockton_new_colors$dark_gray),
        rect = ggplot2::element_rect(linetype = 0, colour = "white"),
        legend.position = "bottom",
        legend.text = ggplot2::element_text(size = 9, colour = "black", family = base_family),
        legend.title = ggplot2::element_blank()
     )
}

#' Set ggplot2 to use custom color scheme
#'
#' Use ggplot2's theming facility to set defaults
#'
#' This function sets the default look (colors, linetypes, etc.) of ggplot2 to
#' match color scheme.  Exhibits not made with ggplot2 will not
#' be affected.
#'
#' @param base_size default font size
#' @param base_family font family to use. Default is "sans".
#'
#' @seealso
#' \code{\link{theme_set}},
#' \code{\link{update_geom_defaults}},
#' \code{\link{gg_lockton_theme}}
#' @examples
#'
#' gg_set_lockton_theme()
#'
#' @export
gg_set_lockton_theme <- function(base_size=10, base_family="Sarabun") {

  if(!(base_family %in% extrafont::fonts())){
    stop(paste0(base_family, " font not found. Run `import_lockton_fonts()` function."))
  }

  extrafont::loadfonts("win", quiet = TRUE)

  # Geoms that only require a default colour.
  ggplot2::update_geom_defaults("point", list(colour = lockton_new_colors$blue,
                                              size = 1.5))
  ggplot2::update_geom_defaults("line", list(colour = lockton_new_colors$blue,
                                             size = 1))
  ggplot2::update_geom_defaults("abline", list(colour = "black",
                                               size = 1))
  ggplot2::update_geom_defaults("hline", list(colour = "black",
                                              size = 1))
  ggplot2::update_geom_defaults("vline", list(colour = "black",
                                              size = 1))

  # Geoms that only require a default fill.
  ggplot2::update_geom_defaults("bar", list(fill = lockton_new_colors$blue))
  ggplot2::update_geom_defaults("col", list(fill = lockton_new_colors$blue))
  ggplot2::update_geom_defaults("area", list(fill = lockton_new_colors$blue))
  ggplot2::update_geom_defaults("ribbon", list(fill = lockton_new_colors$blue))

  # Special geoms.
  ggplot2::update_geom_defaults("boxplot", list(colour = "white",
                                                fill = lockton_new_colors$blue))
  ggplot2::update_geom_defaults("smooth", list(colour = lockton_new_colors$blue,
                                               fill = lockton_new_colors$dark_gray))
  ggplot2::update_geom_defaults("dotplot", list(colour = lockton_new_colors$blue,
                                                fill = lockton_new_colors$dark_gray))

  ggplot2::theme_set(gg_lockton_theme(base_size=10, base_family=base_family))
}

