
#' Format number in comma style
#'
#' @param x numeric vector
#' @param digits number of digits to keep
#' @param ... additional parameters passed to [formatC]
#'
#' @return character vector of formatted numbers
#' @export
#'
#' @examples
#' number_format(10000.12, digits = 2)
#'
number_format <- function(x, digits = 0, ...){

  stopifnot(is.numeric(x))

  formatC(x, big.mark = ",", digits = digits, format = "f", ...)

}

#' Format number in percent style
#'
#' @param x numeric vector
#' @param digits number of digits to keep
#' @param ... additional parameters passed to [formatC]
#'
#' @return character vector of formatted percentages
#' @export
#'
#' @examples
#' pct_format(0.8546, digits = 2)
#'
pct_format <- function(x, digits = 2, ...){

  stopifnot(is.numeric(x))

  paste0(number_format(x * 100, digits = digits, ...), "%")

}
