
<!-- README.md is generated from README.Rmd. Please edit that file -->

# locktonr

<!-- badges: start -->

<!-- badges: end -->

This is an internal Lockton Global Re R package that provides various
convenience functions to make working with R easier.

Examples tasks include:

  - Lockton theme for [ggplot](http://ggplot2.org)
  - Lockton theme for
    [flextable](https://davidgohel.github.io/flextable/)
  - Functions to create Lockton pptx files using
    [officer](https://davidgohel.github.io/officer/)
  - Import and export information to/from Excel files
  - Easily connect to Lockton servers
  - Others tbd…

## Installation

You can install the development version from GitHub using the `remotes`
package:

``` r
# install.packages("remotes")
#remotes::install_github("problemofpoints/locktonr")
library(locktonr)
library(ggplot2)
library(flextable)
```

## Install Lockton fonts

The Lockton fonts are “EB Garamond” for display/titles and “Sarabun” for
text/subheads.These fonts are included with this package. The function
`import_lockton_fonts()` will install the fonts on your machine.

## Custom ggplot themes

The `gg_set_lockton_theme` function sets the default color for the
common types of plots, called `geoms` in `ggplot2`. Put the following at
the top of every R script to have all your ggplots use the custom
Lockton theme.

``` r
gg_set_lockton_theme()
```

Example of a scatterplot with Lockton theme.

``` r
ggplot(data = mtcars, aes(x = wt, y = mpg)) + 
  geom_point() + 
  ggtitle("A simple scatterplot")
```

<img src="man/figures/README-unnamed-chunk-4-1.png" width="100%" />

There is also a Lockton color palette that is available.

``` r
ggplot(data = mtcars, aes(x = wt, y = mpg, color = factor(cyl))) + 
  geom_point() + 
  scale_color_lockton() +
  ggtitle("A simple scatterplot")
```

<img src="man/figures/README-unnamed-chunk-5-1.png" width="100%" />

## Flextable custom theme

The following is an example of using the custom Lockton `flextable`
theme.

``` r
ft <- flextable::regulartable(head(iris)) %>% 
  ft_lockton_theme() %>% 
  add_title_header("Sample table")
```
